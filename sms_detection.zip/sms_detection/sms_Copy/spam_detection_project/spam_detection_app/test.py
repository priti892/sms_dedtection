import json
from django.conf import settings


def save_model(model, weights_path, architecture_path):
    """
    Save the model's weights and architecture separately.

    Parameters:
        model: trained machine learning model
            The trained model to be saved.
        weights_path: str
            The file path to save the model weights.
        architecture_path: str
            The file path to save the model architecture.
    """
    # Save model weights
    model.save_weights(weights_path)

    # Save model architecture
    with open(architecture_path, 'w') as f:
        json.dump(model.to_json(), f)

# Assuming you have already trained your model and have it stored in the variable 'model'

# Specify file paths for weights and architecture
weights_path = 'weights.pkl'
architecture_path = 'architecture.pkl'

# Save model weights and architecture
save_model(settings.SPAM_DETECTION_MODEL_PATH, weights_path, architecture_path)
