import numpy as np
import pandas as pd
import pickle
from django.conf import settings
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import load_model

def load_spam_detection_model(file_path):
    try:
        model = load_model(file_path)
        print("Model loaded successfully.")
        return model
    except OSError as e:
        print(f"Error loading the model: {e}")
        return None

# Save the trained model as an HDF5 file


data = pd.read_csv(r'C:\Users\rucha\OneDrive\Desktop\email_spam.csv')

label_counts = data['label'].value_counts()

spam_data = data[data['label'] == 1].sample(n=1000, random_state=42)
non_spam_data = data[data['label'] == 0].sample(n=1000, random_state=42)

sample_data = pd.concat([spam_data, non_spam_data])

X = sample_data['text'].values
y = sample_data['label'].values

X_train, X_test, y_train, y_test = train_test_split(
    sample_data['text'], sample_data['label'], test_size=0.2, random_state=42)

tokenizer = Tokenizer()
tokenizer.fit_on_texts(X_train)
X_train_seq = tokenizer.texts_to_sequences(X_train)
X_test_seq = tokenizer.texts_to_sequences(X_test)

max_len = max(len(seq) for seq in X_train_seq)

def predict_spam(sample_message, model):
    # Preprocess the test message
    test_message_seq = tokenizer.texts_to_sequences([sample_message])
    test_message_pad = pad_sequences(test_message_seq, maxlen=max_len)
    
    # Make prediction
    prediction = model.predict(test_message_pad)
    
    # Convert prediction to percentage likelihood
    spam_percentage = prediction[0][0] * 100
    not_spam_percentage = 100 - spam_percentage
    
    if spam_percentage >= 50:
        return "Spam", f'Spam percentage: {spam_percentage}', f'Not spam percentage: {not_spam_percentage}'
    else:
        return "Not Spam", f'Spam percentage: {spam_percentage}', f'Not spam percentage: {not_spam_percentage}'

test_message = """
Hi All, Please be available, this time slot – Sohrab, from Orquesta.cloud will be training us on the entire platform, be ready with your queries, questions at the end of Training. Middle of training, I would request you all took a note on your questions, so our agenda can be meet. Feel free to send any martial you want us to go through before training! @Sohrab Hosseini<mailto:sohrab@orquesta.cloud>. Join Meeting : https://meeting.thegatewaycorp.com/b/mad-fnm-axl-dcv 16th Jan 2024 : 2:30 to 4:00 PM Have a wonderful day and keep learning. Regards, Madhav
"""

model = load_spam_detection_model(settings.SPAM_DETECTION_MODEL_PATH)

predicted_label = predict_spam(test_message, model)

print("Predicted Label:", predicted_label)