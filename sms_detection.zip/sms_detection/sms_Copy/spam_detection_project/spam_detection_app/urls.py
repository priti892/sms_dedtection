from django.urls import path
from . import views
from .views import EmailListCreateAPIView, EmailRetrieveUpdateDestroyAPIView

urlpatterns = [
    path('', views.home, name='home'),
    path('emails/', EmailListCreateAPIView.as_view(), name='email-list-create'),
    path('emails/<int:pk>/', EmailRetrieveUpdateDestroyAPIView.as_view(), name='email-detail'),
]

