from django.db import models
from .utils import load_spam_detection_model, predict_spam
from django.conf import settings

class Email(models.Model):
    text = models.TextField()
    is_spam = models.TextField()

    def save(self, *args, **kwargs):
        if self.pk is None:  # If the instance is being created
            model = load_spam_detection_model(settings.SPAM_DETECTION_MODEL_PATH)
            prediction = predict_spam(model, self.text)
            self.is_spam = prediction

        super().save(*args, **kwargs)

    def __str__(self):
        return self.text
